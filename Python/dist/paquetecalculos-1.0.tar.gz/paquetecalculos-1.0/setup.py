from setuptools import setup

setup(
    name="paquetecalculos",
    version="1.0",
    description="Paquete de redondeo y potencia",
    author="Rafa",
    author_email="rafaelrodriguezcalvente@gmail.com",
    url="https://www.linkedin.com/in/rafael-rodr%C3%ADguez-calvente-77024913a/",
    packages=["calculos","calculos.redondeo_potencia"]
)